create unique index if not exists
  elevenlabs_conversations_conversation_id_key
on elevenlabs_conversations (conversation_id);
