import { updateProvisionRun } from '../store';

export async function vercelExecute(run: any) {
  // Vercel deployment assumed triggered externally (CLI / webhook)
  // Execution step marks that deployment should now exist

  await updateProvisionRun(run.project_slug, {
    state: 'VERCEL_READY',
  });

  return { state: 'VERCEL_READY' };
}
