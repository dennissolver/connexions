import { updateProvisionRun } from '../store';

export async function supabaseExecute(run: any) {
  // Supabase project should already exist by this stage
  // Execution step records that Supabase provisioning is logically complete
  await updateProvisionRun(run.project_slug, {
    state: 'SUPABASE_READY',
  });

  return { state: 'SUPABASE_READY' };
}
