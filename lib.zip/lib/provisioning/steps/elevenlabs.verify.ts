export async function elevenVerify(run: any) {
  try {
    const res = await fetch(
      `https://api.elevenlabs.io/v1/agents/${run.metadata?.eleven_agent_id}/ping`,
      {
        headers: {
          Authorization: `Bearer ${process.env.ELEVENLABS_API_KEY}`,
        },
      }
    );

    return res.ok;
  } catch {
    return false;
  }
}
