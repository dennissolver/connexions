export async function supabaseVerify(run: any) {
  const supabaseUrl = run.metadata?.supabase_site_url;
  const vercelUrl = run.metadata?.vercel_url;

  if (!supabaseUrl || !vercelUrl) return false;

  try {
    const res = await fetch(supabaseUrl, { method: 'GET' });
    if (!res.ok) return false;

    const body = await res.text();
    return body.includes(vercelUrl);
  } catch {
    return false;
  }
}
