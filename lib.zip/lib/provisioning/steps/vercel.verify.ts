export async function vercelVerify(run: any) {
  return Boolean(
    run.metadata?.vercel_project_id &&
    run.metadata?.vercel_url
  );
}
