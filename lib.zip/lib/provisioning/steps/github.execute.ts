import { updateProvisionRun } from '../store';

export async function githubExecute(run: any) {
  // Repo creation happens earlier; this marks readiness
  await updateProvisionRun(run.project_slug, {
    state: 'GITHUB_READY',
  });

  return { state: 'GITHUB_READY' };
}
