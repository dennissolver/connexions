export async function githubVerify(run: any) {
  return Boolean(
    run.metadata?.github_repo &&
    run.metadata?.github_commit_sha
  );
}
