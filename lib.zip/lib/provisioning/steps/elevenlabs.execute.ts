import { updateProvisionRun } from '../store';

export async function elevenExecute(run: any) {
  // Agent creation handled upstream
  await updateProvisionRun(run.project_slug, {
    state: 'ELEVEN_READY',
  });

  return { state: 'ELEVEN_READY' };
}
