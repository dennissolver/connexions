export const DEFAULT_DASHBOARD_METRICS = {
  total_agents: 0,
  total_interviews: 0,
  total_panels: 0,
};
