// app/api/get-transcript/route.ts
// Retrieves transcript from ElevenLabs conversation or our DB

import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const conversationId = searchParams.get('conversationId');

    if (!conversationId) {
      return NextResponse.json(
        { error: 'conversationId required' },
        { status: 400 }
      );
    }

    // Try to get from our database first (from webhook)
    const { data: session } = await supabase
      .from('setup_sessions')
      .select('transcript, messages, status')
      .eq('conversation_id', conversationId)
      .single();

    if (session?.transcript) {
      return NextResponse.json({
        transcript: session.transcript,
        source: 'database',
      });
    }

    if (session?.messages && session.messages.length > 0) {
      const transcript = formatMessages(session.messages);
      return NextResponse.json({
        transcript,
        source: 'database_messages',
      });
    }

    // Try ElevenLabs API
    const elevenlabsApiKey = process.env.ELEVENLABS_API_KEY;
    if (elevenlabsApiKey) {
      try {
        const response = await fetch(
          `https://api.elevenlabs.io/v1/convai/conversations/${conversationId}`,
          {
            headers: {
              'xi-api-key': elevenlabsApiKey,
            },
          }
        );

        if (response.ok) {
          const data = await response.json();
          
          if (data.transcript) {
            // Save to DB for future use
            await supabase
              .from('setup_sessions')
              .upsert({
                conversation_id: conversationId,
                transcript: typeof data.transcript === 'string' 
                  ? data.transcript 
                  : formatMessages(data.transcript),
                messages: data.transcript,
                updated_at: new Date().toISOString(),
              });

            return NextResponse.json({
              transcript: typeof data.transcript === 'string'
                ? data.transcript
                : formatMessages(data.transcript),
              source: 'elevenlabs',
            });
          }
        }
      } catch (err) {
        console.warn('ElevenLabs fetch failed:', err);
      }
    }

    // If still no transcript, the conversation might still be in progress
    return NextResponse.json(
      { error: 'Transcript not available yet. Please wait for the conversation to complete.' },
      { status: 404 }
    );

  } catch (error: any) {
    console.error('Get transcript error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to get transcript' },
      { status: 500 }
    );
  }
}

function formatMessages(messages: any[]): string {
  if (!Array.isArray(messages)) return String(messages);
  
  return messages
    .map(m => {
      const role = m.role === 'agent' || m.role === 'assistant' 
        ? 'Agent' 
        : 'User';
      return `${role}: ${m.content || m.text || m.message}`;
    })
    .join('\n\n');
}
